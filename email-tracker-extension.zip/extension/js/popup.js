// Handle popup interactions
document.addEventListener('DOMContentLoaded', function() {
  // Add any popup-specific functionality here
  console.log('Email Tracker popup loaded');
});
